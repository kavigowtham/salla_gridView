document.onreadystatechange = function () {
  if (document.readyState === 'interactive') renderApp();

  function renderApp() {
    var onInit = app.initialized();

    onInit.then(getClient).catch(handleErr);

    function getClient(_client) {
      window.client = _client;
      client.events.on('app.activated', onAppActivate);
    }
  }
};

function onAppActivate() {
  client.iparams.get().then(data => {
    console.log(data, "this is data")
    console.log(data.salladomain,"salla")
    let url1 = `https://api.salla.dev/admin/v2`;

    let options = {
      headers: {
        'Authorization': `Bearer <%= (iparam.sallaapi) %>`,
        "Content-Type": "application/json;"
      }
      
    }

    let iparams=data;
    console.log("iparams",iparams.salladomain)
    let payload = [];
    // payload.push(data)
    client.data.get("requester").then(data => {
      let reqEmail = data.requester.email;
      console.log("requester data", reqEmail)


      //Order button
      $(document).on('click', '#order', function () {
        modalTrigger()
      })
      //Trigger Modal
      function modalTrigger() {
     
        payload.push(options)
        console.log(payload[0],',,,,,,url')
        client.request.get(`https://${iparams.salladomain}/admin/v2/orders?query="email:${reqEmail}`, options).then(data => {
          console.log("this is payload data", JSON.parse(data.response).data.length)
          let orderData = JSON.parse(data.response).data;
          payload.push(orderData)
          payload.push(reqEmail)
          payload.push(iparams)
          payload.push(url1)
          console.log(payload,',,,,,,payload')
          client.interface.trigger("showModal", {
            title: "Order Details",
            template: "modal1.html",
            data: payload,
          }).then(function (data) {
            console.log("success", data)
          }).catch(function (error) {
            handleErr(error)
          });
        }, function (err) {
          handleErr(err)
        })

      }
    }, function (err) {
      handleErr(err)
    })
  }, function (err) {
    handleErr(err)
  })
}

function handleErr(err) {
  console.error(`Error occured. Details:`, err);
}
